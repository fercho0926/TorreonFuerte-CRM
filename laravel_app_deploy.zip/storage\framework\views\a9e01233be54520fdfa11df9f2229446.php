<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso al sistema</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --text: #0f172a;
            --muted: #64748b;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text);
        }
        .card {
            background: white;
            width: 100%;
            max-width: 420px;
            padding: 2rem;
            border-radius: 18px;
            box-shadow: 0 20px 45px rgba(37, 99, 235, 0.16);
        }
        .brand {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .brand h1 { margin: 0 0 0.4rem; font-size: 1.5rem; }
        .brand p { margin: 0; color: var(--muted); font-size: 0.95rem; }
        .field { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.4rem; font-weight: 600; }
        input {
            width: 100%;
            padding: 0.85rem 0.95rem;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 0.95rem;
        }
        button {
            width: 100%;
            padding: 0.9rem;
            border: none;
            border-radius: 10px;
            background: var(--primary);
            color: white;
            font-weight: 700;
            cursor: pointer;
            margin-top: 0.5rem;
        }
        button:hover { background: var(--primary-dark); }
        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 0.7rem 0.9rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            font-size: 0.95rem;
        }
        .hint {
            margin-top: 1rem;
            font-size: 0.9rem;
            color: var(--muted);
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="brand">
            <h1>CRM Panel</h1>
            <p>Ingrese sus credenciales para continuar</p>
        </div>

        <?php if($errors->any()): ?>
            <div class="error">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login.post')); ?>">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label for="email">Correo electrónico</label>
                <input id="email" type="email" name="email" required value="<?php echo e(old('email')); ?>" placeholder="admin@example.com">
            </div>
            <div class="field">
                <label for="password">Contraseña</label>
                <input id="password" type="password" name="password" required placeholder="********">
            </div>
            <button type="submit">Ingresar</button>
        </form>

        <div class="hint">
            Demo: admin@example.com / password
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/torreonf/crm.torreonfuerte.org.co/laravel_app/resources/views/auth/login.blade.php ENDPATH**/ ?>