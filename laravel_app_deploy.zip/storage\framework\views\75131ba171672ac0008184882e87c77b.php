<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8fafc;
            margin: 0;
            padding: 2rem;
            color: #0f172a;
        }
        .box {
            background: white;
            max-width: 700px;
            margin: 2rem auto;
            padding: 2rem;
            border-radius: 18px;
            box-shadow: 0 12px 35px rgba(15, 23, 42, 0.08);
        }
        .pill {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            background: #dbeafe;
            color: #1d4ed8;
            border-radius: 999px;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        button {
            padding: 0.8rem 1rem;
            border: none;
            border-radius: 10px;
            background: #dc2626;
            color: white;
            cursor: pointer;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="box">
        <div class="pill">Sesión iniciada correctamente</div>
        <h1>Bienvenido, <?php echo e($userName); ?></h1>
        <p>Este sistema está funcionando con autenticación simple sin base de datos.</p>
        <p>Pronto podrás reemplazar esta pantalla por tu CRM real.</p>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">Cerrar sesión</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH /home/torreonf/crm.torreonfuerte.org.co/laravel_app/resources/views/dashboard.blade.php ENDPATH**/ ?>